from gpiozero import Button
from subprocess import check_call
from signal import pause

def shutdown():
    check_call(['sudo', 'poweroff'])

def reboot():
    check_call(['sudo', 'reboot'])

btn_1 = Button(21, hold_time=5)
btn_2 = Button(20, hold_time=3)
btn_3 = Button(16, hold_time=3)

btn_1.when_held = shutdown
btn_3.when_held = reboot

pause()