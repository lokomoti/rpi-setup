cd /home/pi/display
sudo python3 lcd_ui.py &
#python3 sys_IO.py &
