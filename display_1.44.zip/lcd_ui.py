import LCD_1in44
import LCD_Config

from gpiozero import Button, LED, CPUTemperature, LoadAverage, PingServer, TimeOfDay, DiskUsage
from signal import pause

#import time
import os
import datetime
from datetime import time
from time import sleep
from PIL import Image,ImageDraw,ImageFont,ImageColor

def init_disp():
    global draw, disp, image
    
    disp = LCD_1in44.LCD()
    Lcd_ScanDir = LCD_1in44.SCAN_DIR_DFT  #SCAN_DIR_DFT = D2U_L2R
    disp.LCD_Init(Lcd_ScanDir)
    disp.LCD_Clear()
    
    # Create blank image for drawing.
    image = Image.new("RGB", (disp.width, disp.height), "BLACK")
    draw = ImageDraw.Draw(image)
    return

def clear_disp():
    # Draw a black filled box to clear the image.
    draw.rectangle((0,0, disp.width, disp.height), outline=0, fill=0)
    disp.LCD_ShowImage(image,0,0)

def get_info():
    load = LoadAverage(min_load_average=0, max_load_average=2).load_average
    cpu_temp = CPUTemperature(min_temp=50, max_temp=90).temperature
    cpu_temp = round(cpu_temp, 1)
    disk = int(DiskUsage().usage)
    return cpu_temp, load, disk

def get_date():
    x = datetime.datetime.now()
    date = x.strftime("%x")
    time = x.strftime("%X")
    
    var = date + "  " + time
    
    return var

def get_ip():
    cmd = "hostname -I"
    ip = str(os.popen(cmd).read())
    ip = str(ip)[0:15]
    return "IP: " + ip

# program settings
menu_items = 5
sub_menu_items = 3

# Initialize defaults
menu_index = 0
sub_menu_index = 0
confirm = False

# Callback functions
def joy_cntr():
    print("center")

def joy_r():
    sub_menu_index += 1
    print(sub_menu_index)
    
def joy_l():
    sub_menu_index -= 1
    print(sub_menu_index)
    
def joy_up():
    menu_index += 1
    print(menu_index)
    
def joy_down():
    menu_index -= 1
    print(menu_index)

def shutdown():
    check_call(['sudo', 'poweroff'])

def reboot():
    check_call(['sudo', 'reboot'])



# Timers
tim_1 = TimeOfDay(time(7), time(8))

# Buttons
btn_1 = Button(21, hold_time=5)
btn_2 = Button(20)
btn_3 = Button(16, hold_time=3)

K_UP_P  = Button(6)
K_DOWN_P = Button(19)
K_LEFT_P = Button(5)
K_RIGHT_P = Button(26)
K_PRESS_P = Button(13)


init_disp()

while True:
    #clear_disp()
    
    # Events
    btn_1.when_held = shutdown
    btn_3.when_held = reboot

    if K_PRESS_P.is_pressed : menu_index = 0#confirm = True
    if K_RIGHT_P.is_pressed : sub_menu_index += 1
    if K_LEFT_P.is_pressed : sub_menu_index -= 1
    if K_DOWN_P.is_pressed : menu_index -= 1
    if K_UP_P.is_pressed : menu_index += 1

    #ping_internet = PingServer("google.com")


    #print(menu_index)
    
    draw = ImageDraw.Draw(image)
    #font = ImageFont.truetype('/usr/share/fonts/truetype/freefont/FreeMonoBold.ttf', 16)
    
    a, b, c = get_info()
    
    a_pos = 18
    b_pos = 28
    c_pos = 38
    d_pos = 48
    
    draw.rectangle([(0,0),(disp.width, 12)],fill = "RED")
    draw.text((0, 0), "System monitoring:", fill = "WHITE")
    
    draw.rectangle([(0,a_pos),(disp.width,a_pos+10)],fill = "BLACK")
    draw.text((0, a_pos), "CPU Temp: " + str(a) + '"C', fill = "WHITE")
    
    draw.rectangle([(0,b_pos),(disp.width,b_pos+10)],fill = "BLACK")
    draw.text((0, b_pos), "CPU Load: " + str(b), fill = "WHITE")
    
    draw.rectangle([(0,c_pos),(disp.width,c_pos+10)],fill = "BLACK")
    draw.text((0, c_pos), "HDD space: " + str(c) + "%", fill = "WHITE")
    
    draw.rectangle([(0,d_pos),(disp.width,d_pos+10)],fill = "BLACK")
    draw.text((0, d_pos), str(get_ip()), fill = "WHITE")
    
    draw.rectangle([(0,disp.height - 22),(disp.width, disp.height)],fill = "RED")
    draw.text((10, disp.height - 22), get_date(), fill = "WHITE")
    
    disp.LCD_ShowImage(image,0,0)
    sleep(0.15)
    #pause()
